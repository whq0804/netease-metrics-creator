---
name: "netease-metrics-creator"
description: "用于在网易有数 BI 平台上批量创建数据指标。当用户需要批量创建指标、管理指标状态或查询指标数据时调用此 skill。"
---

# 网易有数 BI 指标批量创建工具

本 skill 用于通过 API 在网易有数 BI 平台上批量创建数据指标。

## 工作流程

1. **收集必要信息**
   - 环境信息：网易有数 BI 域名、token-key
   - 项目信息：projectId
   - 模型清单：模型名称、模型 ID (dataModelId)
   - 指标清单：指标名称、计算字段、聚合方式、维度、筛选条件等

2. **生成 Token**
   - 使用 tokenKey 方式调用 `/api/dash/util/genToken` 生成访问 token

3. **批量创建指标**
   - 调用 `/api/dash/metrics/ext/add` 接口逐个或批量创建指标

## API 接口说明

### 1. 生成 Token

```
POST /api/dash/util/genToken
```

请求参数：
| 字段 | 类型 | 说明 |
|------|------|------|
| tokenType | String | 'tokenKey' |
| key | String | 用户生成的 token key |

### 2. 添加指标

```
POST /api/dash/metrics/ext/add
```

核心请求参数：
| 字段 | 类型 | 说明 |
|------|------|------|
| token | String | token 校验 |
| projectId | Int | 项目 ID |
| name | String | 指标名称 |
| dataModelId | Int | 原始数据模型 ID |
| type | String | 指标类型：'Existed' |
| caliber | String | 指标口径 |
| setting | Object | 指标计算配置 |

**MetricsSetting 结构：**

```json
{
  "field": {
    "$type": "Dimension|Measure",
    "alias": "字段别名",
    "aggregator": "SUM|AVG|CNT|CNTD|MAX|MIN|ATTR|MEDIAN|PERCENTILE"
  },
  "dimensions": [
    {
      "$type": "Dimension",
      "alias": "维度字段别名"
    }
  ],
  "filters": [
    {
      "$type": "DFilter",
      "pill": {
        "$type": "Dimension",
        "alias": "筛选字段别名"
      },
      "filter": {
        "$type": "DiscreteDimensionFilter",
        "mode": "manual",
        "select": ["选中值1", "选中值2"],
        "unselect": ["排除值1"]
      }
    }
  ],
  "dateDimension": {
    "$type": "Dimension",
    "alias": "日期字段别名",
    "mapFunction": "YEAR-MONTH-DAY|TRUNC-YEAR|YEAR-MONTH|YEAR-QUARTER"
  },
  "dataPeriod": "day|week|month|quarter|year",
  "formatConfig": {
    "type": "auto|percent|decimal|time",
    "decimalPlace": 2,
    "unit": "万|千|h",
    "prefix": "",
    "suffix": "",
    "thousandSeparator": true
  }
}
```

### 3. 修改指标状态

```
POST /api/dash/metrics/ext/updateStatus
```

请求参数：
| 字段 | 类型 | 说明 |
|------|------|------|
| token | String | token 校验 |
| projectId | Int | 项目 ID |
| metricsNames | Array[String] | 指标名称列表 |
| status | Int | 0-下线，1-上线 |

### 4. 查询指标数据

```
POST /api/dash/metrics/ext/batchQueryData
```

请求参数：
| 字段 | 类型 | 说明 |
|------|------|------|
| token | String | token 校验 |
| projectId | Int | 项目 ID |
| metricsIds | Array[Int] | 指标 ID 列表 |
| dimensions | Array | 维度列表（可选） |
| filters | Array | 过滤条件（可选） |
| offsetLimit | Array[Int] | 分页 [offset, limit] |

## 指标清单格式示例

用户应提供如下格式的指标清单：

```json
{
  "environment": {
    "domain": "https://dash.youdata.com",
    "tokenKey": "your-token-key"
  },
  "project": {
    "projectId": 64599
  },
  "models": [
    {
      "name": "费用明细",
      "dataModelId": 700304615
    }
  ],
  "metrics": [
    {
      "name": "总费用金额",
      "nameEn": "TotalExpense",
      "caliber": "统计所有费用金额的总和",
      "dataModelId": 700304615,
      "field": {
        "alias": "费用金额",
        "aggregator": "SUM"
      },
      "dimensions": ["日期", "公司名称"],
      "filters": [
        {
          "field": "费用属性名称",
          "select": ["营业成本"]
        }
      ],
      "dateDimension": "日期",
      "dataPeriod": "day",
      "formatConfig": {
        "type": "decimal",
        "decimalPlace": 2,
        "unit": "万",
        "thousandSeparator": true
      }
    }
  ]
}
```

## Python 调用示例

```python
import requests
import json

class NeteaseMetricsCreator:
    def __init__(self, domain, token_key, project_id):
        self.domain = domain
        self.token_key = token_key
        self.project_id = project_id
        self.token = None
    
    def generate_token(self):
        """生成访问 token"""
        url = f"{self.domain}/api/dash/util/genToken"
        payload = {
            "tokenType": "tokenKey",
            "key": self.token_key
        }
        response = requests.post(url, json=payload)
        self.token = response.json().get("token")
        return self.token
    
    def create_metric(self, metric_config):
        """创建单个指标"""
        url = f"{self.domain}/api/dash/metrics/ext/add"
        
        payload = {
            "token": self.token,
            "projectId": self.project_id,
            "name": metric_config["name"],
            "nameEn": metric_config.get("nameEn", ""),
            "caliber": metric_config.get("caliber", ""),
            "dataModelId": metric_config["dataModelId"],
            "type": "Existed",
            "enableChatBi": 1,
            "enableMetricExploration": 0,
            "setting": self._build_setting(metric_config)
        }
        
        response = requests.post(url, json=payload)
        return response.json()
    
    def _build_setting(self, config):
        """构建指标配置"""
        setting = {
            "field": {
                "$type": "Measure",
                "alias": config["field"]["alias"],
                "aggregator": config["field"]["aggregator"]
            }
        }
        
        # 添加维度
        if "dimensions" in config:
            setting["dimensions"] = [
                {"$type": "Dimension", "alias": dim}
                for dim in config["dimensions"]
            ]
        
        # 添加筛选条件
        if "filters" in config:
            setting["filters"] = [
                {
                    "$type": "DFilter",
                    "pill": {"$type": "Dimension", "alias": f["field"]},
                    "filter": {
                        "$type": "DiscreteDimensionFilter",
                        "mode": "manual",
                        "select": f.get("select", []),
                        "unselect": f.get("unselect", [])
                    }
                }
                for f in config["filters"]
            ]
        
        # 添加日期维度
        if "dateDimension" in config:
            setting["dateDimension"] = {
                "$type": "Dimension",
                "alias": config["dateDimension"],
                "mapFunction": "YEAR-MONTH-DAY"
            }
        
        # 添加统计周期
        if "dataPeriod" in config:
            setting["dataPeriod"] = config["dataPeriod"]
        
        # 添加格式配置
        if "formatConfig" in config:
            setting["formatConfig"] = config["formatConfig"]
        
        return setting
    
    def batch_create_metrics(self, metrics_list):
        """批量创建指标"""
        results = []
        for metric in metrics_list:
            result = self.create_metric(metric)
            results.append({
                "name": metric["name"],
                "result": result
            })
        return results
    
    def update_metrics_status(self, metric_names, status=1):
        """批量修改指标状态"""
        url = f"{self.domain}/api/dash/metrics/ext/updateStatus"
        payload = {
            "token": self.token,
            "projectId": self.project_id,
            "metricsNames": metric_names,
            "status": status
        }
        response = requests.post(url, json=payload)
        return response.json()
    
    def query_metrics_data(self, metrics_ids, dimensions=None, filters=None, offset=0, limit=100):
        """查询指标数据"""
        url = f"{self.domain}/api/dash/metrics/ext/batchQueryData"
        payload = {
            "token": self.token,
            "projectId": self.project_id,
            "metricsIds": metrics_ids,
            "offsetLimit": [offset, limit]
        }
        
        if dimensions:
            payload["dimensions"] = [
                {"$type": "CommonDimension", "field": dim}
                for dim in dimensions
            ]
        
        if filters:
            payload["filters"] = filters
        
        response = requests.post(url, json=payload)
        return response.json()


# 使用示例
if __name__ == "__main__":
    # 初始化
    creator = NeteaseMetricsCreator(
        domain="https://dash.youdata.com",
        token_key="your-token-key",
        project_id=64599
    )
    
    # 生成 token
    creator.generate_token()
    
    # 定义指标清单
    metrics = [
        {
            "name": "测试指标1",
            "caliber": "测试口径",
            "dataModelId": 700304615,
            "field": {"alias": "费用金额", "aggregator": "SUM"},
            "dimensions": ["日期"],
            "dateDimension": "日期",
            "dataPeriod": "day"
        }
    ]
    
    # 批量创建
    results = creator.batch_create_metrics(metrics)
    print(json.dumps(results, indent=2, ensure_ascii=False))
```

## 注意事项

1. **Token 有效期**：生成的 token 有有效期限制，如过期需要重新生成
2. **权限检查**：确保 token 对应的账号有相应的项目权限和文件夹权限
3. **字段校验**：创建指标时，字段别名必须与数据模型中的字段一致
4. **聚合方式**：聚合方式必须与字段类型匹配（如数值型字段可用 SUM，字符串型字段只能用 CNT/CNTD/ATTR）
5. **指标名称**：同一项目下指标名称不能重复
6. **模型 ID**：dataModelId 必须是已存在且可用的数据模型

## 常见问题

**Q: 如何获取 dataModelId？**
A: 可以在网易有数 BI 平台的数据准备页面查看模型详情，或通过获取指标详情接口反查。

**Q: 指标创建失败的可能原因？**
A: 
- 字段别名不存在于数据模型中
- 聚合方式与字段类型不匹配
- 指标名称重复
- 没有文件夹创建权限
- Token 过期或权限不足

**Q: 如何批量上线/下线指标？**
A: 使用 `/api/dash/metrics/ext/updateStatus` 接口，传入指标名称列表和状态值（0-下线，1-上线）。
